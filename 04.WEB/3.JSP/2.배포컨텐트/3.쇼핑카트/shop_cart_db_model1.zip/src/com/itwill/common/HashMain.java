package com.itwill.common;
import com.itwill.common.Util;

public class HashMain {

	public static void main(String[] args) {
		System.out.println(Util.getHashedString("1111","SHA-1"));
		System.out.println(Util.getHashedString("2222","SHA-1"));
		System.out.println(Util.getHashedString("3333","SHA-1"));
		

	}

}
